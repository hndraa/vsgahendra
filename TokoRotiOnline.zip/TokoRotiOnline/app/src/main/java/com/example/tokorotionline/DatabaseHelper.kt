package com.example.tokorotionline // PASTIKAN NAMA PACKAGE INI SESUAI PROYEK ANDA

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Model data untuk Roti
data class Product(val id: Long, val name: String, val description: String, val price: Double)

// Model data untuk Pesanan
data class Order(val id: Long, val customerName: String, val productName: String, val latitude: Double, val longitude: Double)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "TokoRoti.db"

        // Tabel Produk
        private const val TABLE_PRODUCTS = "products"
        private const val KEY_ID = "id"
        private const val KEY_NAME = "name"
        private const val KEY_DESCRIPTION = "description"
        private const val KEY_PRICE = "price"

        // Tabel Pesanan
        private const val TABLE_ORDERS = "orders"
        private const val KEY_ORDER_ID = "id"
        private const val KEY_CUSTOMER_NAME = "customer_name"
        private const val KEY_PRODUCT_NAME = "product_name"
        private const val KEY_LATITUDE = "latitude"
        private const val KEY_LONGITUDE = "longitude"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createProductsTable = ("CREATE TABLE " + TABLE_PRODUCTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_DESCRIPTION + " TEXT,"
                + KEY_PRICE + " REAL" + ")")
        db?.execSQL(createProductsTable)

        val createOrdersTable = ("CREATE TABLE " + TABLE_ORDERS + "("
                + KEY_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_CUSTOMER_NAME + " TEXT,"
                + KEY_PRODUCT_NAME + " TEXT,"
                + KEY_LATITUDE + " REAL,"
                + KEY_LONGITUDE + " REAL" + ")")
        db?.execSQL(createOrdersTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUCTS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_ORDERS")
        onCreate(db)
    }

    /**
     * FUNGSI KRUSIAL: Memeriksa dan menambahkan produk dalam satu koneksi database.
     * Ini memastikan data sudah siap sebelum halaman lain memintanya.
     */
    fun addInitialProducts() {
        val db = this.writableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM $TABLE_PRODUCTS", null)
        cursor.moveToFirst()
        val count = cursor.getInt(0)
        cursor.close()

        // Hanya tambahkan produk jika tabel benar-benar kosong
        if (count == 0) {
            addProduct(db, Product(0, "Roti Tawar", "Roti tawar gandum premium", 15000.0))
            addProduct(db, Product(0, "Kue Coklat", "Kue coklat dengan topping keju", 25000.0))
            addProduct(db, Product(0, "Donat Gula", "Donat empuk dengan taburan gula halus", 5000.0))
        }
    }

    private fun addProduct(db: SQLiteDatabase, product: Product) {
        val values = ContentValues()
        values.put(KEY_NAME, product.name)
        values.put(KEY_DESCRIPTION, product.description)
        values.put(KEY_PRICE, product.price)
        db.insert(TABLE_PRODUCTS, null, values)
    }

    fun getAllProducts(): List<Product> {
        val productList = ArrayList<Product>()
        val selectQuery = "SELECT * FROM $TABLE_PRODUCTS"
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery(selectQuery, null)
        try {
            if (cursor.moveToFirst()) {
                do {
                    val product = Product(
                        cursor.getLong(cursor.getColumnIndexOrThrow(KEY_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_PRICE))
                    )
                    productList.add(product)
                } while (cursor.moveToNext())
            }
        } finally {
            cursor.close()
            db.close()
        }
        return productList
    }

    fun addOrder(order: Order) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(KEY_CUSTOMER_NAME, order.customerName)
        values.put(KEY_PRODUCT_NAME, order.productName)
        values.put(KEY_LATITUDE, order.latitude)
        values.put(KEY_LONGITUDE, order.longitude)
        db.insert(TABLE_ORDERS, null, values)
        db.close()
    }

    fun getAllOrders(): List<Order> {
        val orderList = ArrayList<Order>()
        val selectQuery = "SELECT * FROM $TABLE_ORDERS"
        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, null)
        try {
            if (cursor.moveToFirst()) {
                do {
                    val order = Order(
                        cursor.getLong(cursor.getColumnIndexOrThrow(KEY_ORDER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_CUSTOMER_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_PRODUCT_NAME)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LATITUDE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(KEY_LONGITUDE))
                    )
                    orderList.add(order)
                } while (cursor.moveToNext())
            }
        } finally {
            cursor.close()
            db.close()
        }
        return orderList
    }
}
