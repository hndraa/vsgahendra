package com.example.tokorotionline

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        val btnGoToUser: Button = findViewById(R.id.btnGoToUser)
        val btnGoToAdmin: Button = findViewById(R.id.btnGoToAdmin)

        // Tombol untuk pindah ke halaman pelanggan (MainActivity)
        btnGoToUser.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Tombol untuk pindah ke halaman admin (AdminActivity)
        btnGoToAdmin.setOnClickListener {
            val intent = Intent(this, AdminActivity::class.java)
            startActivity(intent)
        }
    }
}
