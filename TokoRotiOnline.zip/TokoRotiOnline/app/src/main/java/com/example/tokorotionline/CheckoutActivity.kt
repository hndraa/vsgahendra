package com.example.tokorotionline

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class CheckoutActivity : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var db: DatabaseHelper

    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private var productName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        db = DatabaseHelper(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Ambil nama produk dari intent
        productName = intent.getStringExtra("PRODUCT_NAME") ?: "Produk Tidak Ditemukan"
        val tvOrdering: TextView = findViewById(R.id.tvOrdering)
        tvOrdering.text = "Anda memesan: $productName"

        val btnGetLocation: Button = findViewById(R.id.btnGetLocation)
        val btnConfirmOrder: Button = findViewById(R.id.btnConfirmOrder)
        val etCustomerName: EditText = findViewById(R.id.etCustomerName)
        val tvCoordinates: TextView = findViewById(R.id.tvCoordinates)

        btnGetLocation.setOnClickListener {
            fetchLocation()
        }

        btnConfirmOrder.setOnClickListener {
            val customerName = etCustomerName.text.toString()
            if (customerName.isEmpty()) {
                Toast.makeText(this, "Nama tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (latitude == 0.0 || longitude == 0.0) {
                Toast.makeText(this, "Silakan dapatkan lokasi Anda terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Simpan pesanan ke database
            val order = Order(0, customerName, productName, latitude, longitude)
            db.addOrder(order)
            Toast.makeText(this, "Pesanan berhasil dibuat!", Toast.LENGTH_LONG).show()
            finish() // Kembali ke halaman utama
        }
    }

    private fun fetchLocation() {
        val tvCoordinates: TextView = findViewById(R.id.tvCoordinates)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Minta izin jika belum ada
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                latitude = location.latitude
                longitude = location.longitude
                tvCoordinates.text = "Koordinat GPS: $latitude, $longitude"
                Toast.makeText(this, "Lokasi berhasil didapatkan", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Gagal mendapatkan lokasi. Pastikan GPS aktif.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Handle hasil permintaan izin
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchLocation() // Coba lagi setelah izin diberikan
            } else {
                Toast.makeText(this, "Izin lokasi ditolak.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}