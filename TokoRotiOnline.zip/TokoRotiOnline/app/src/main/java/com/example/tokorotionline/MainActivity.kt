package com.example.tokorotionline

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var productAdapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)

        // Tambahkan data roti awal (hanya jika database kosong)
        db.addInitialProducts()

        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewProducts)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Muat data produk dan tampilkan di RecyclerView
        val productList = db.getAllProducts()
        productAdapter = ProductAdapter(productList)
        recyclerView.adapter = productAdapter

        
    }

    override fun onResume() {
        super.onResume()
        // Refresh list jika ada perubahan (opsional, tapi bagus)
        val productList = db.getAllProducts()
        productAdapter = ProductAdapter(productList)
        findViewById<RecyclerView>(R.id.recyclerViewProducts).adapter = productAdapter
    }
}