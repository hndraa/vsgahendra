package com.example.tokorotionline // PASTIKAN NAMA PACKAGE INI SESUAI PROYEK ANDA

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Persiapan awal (hanya sekali)
        db = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recyclerViewProducts)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // 2. Panggil fungsi untuk mengisi data produk jika database masih kosong.
        // Fungsi ini aman dipanggil di sini.
        db.addInitialProducts()
    }

    /**
     * 3. onResume() dipanggil SETIAP KALI halaman ini akan ditampilkan.
     * Dengan memuat data di sini, kita memastikan daftar produk selalu
     * yang terbaru dan ditampilkan dengan benar, MENGATASI MASALAH LAYAR KOSONG.
     */
    override fun onResume() {
        super.onResume()
        loadProducts()
    }

    private fun loadProducts() {
        // Ambil data terbaru dari database dan tampilkan ke RecyclerView
        val productList = db.getAllProducts()
        recyclerView.adapter = ProductAdapter(productList)
    }
}
