package com.example.tokorotionline // PASTIKAN NAMA PACKAGE INI SESUAI PROYEK ANDA

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.NumberFormat
import java.util.*

class ProductAdapter(private val productList: List<Product>) :
    RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.tvProductName)
        val description: TextView = itemView.findViewById(R.id.tvProductDescription)
        val price: TextView = itemView.findViewById(R.id.tvProductPrice)
        val buyButton: Button = itemView.findViewById(R.id.btnBuy)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val currentItem = productList[position]
        holder.name.text = currentItem.name
        holder.description.text = currentItem.description

        val formatRupiah = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
        holder.price.text = formatRupiah.format(currentItem.price)

        holder.buyButton.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, CheckoutActivity::class.java).apply {
                putExtra("PRODUCT_NAME", currentItem.name)
            }
            context.startActivity(intent)
        }
    }

    // Fungsi ini sangat penting! Pastikan tidak selalu mengembalikan 0.
    override fun getItemCount() = productList.size
}
