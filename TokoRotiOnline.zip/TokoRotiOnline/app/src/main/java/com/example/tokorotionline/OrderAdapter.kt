package com.example.tokorotionline

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class OrderAdapter(private val orderList: List<Order>) :
    RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val customerName: TextView = itemView.findViewById(R.id.tvAdminCustomerName)
        val productName: TextView = itemView.findViewById(R.id.tvAdminProductName)
        val coordinates: TextView = itemView.findViewById(R.id.tvAdminCoordinates)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orderList[position]
        holder.customerName.text = order.customerName
        holder.productName.text = "Pesanan: ${order.productName}"
        holder.coordinates.text = "Lokasi: ${order.latitude}, ${order.longitude}"
    }

    override fun getItemCount() = orderList.size
}